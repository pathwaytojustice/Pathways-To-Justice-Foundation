
# Pathways to Justice Foundation — Static Website (v4)

What’s new in v4:
- Donate buttons wired to **PayPal Sandbox** test link (https://www.sandbox.paypal.com/donate?hosted_button_id=TEST123). Replace with your real link later.
- **Thank You** page at `/thanks.html`; the contact form redirects here after submission.
- **News** page template with sample items you can edit/duplicate.

## Replace PayPal Sandbox with live links
- Edit `donate.html` and swap `https://www.sandbox.paypal.com/donate?hosted_button_id=TEST123` with your real PayPal/Donorbox URLs.
- You can also keep the suggested amount links and update them to your processor's format.

## Netlify Forms
- The contact form includes `data-netlify="true"` and `action="/thanks.html"`.
- On Netlify, submissions are captured automatically and users are redirected to the Thank You page.

## Google Analytics
- Replace `G-XXXXXXXXXX` in each page `<head>` with your GA4 Measurement ID.

## Deploy free
- **GitHub Pages** or **Netlify**: upload this folder and publish.
